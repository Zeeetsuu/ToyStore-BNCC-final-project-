<?php
require_once __DIR__ . '/views/partials/header.php';
?>

<h1>Welcome to Toys Store</h1>
<p>Find your favorite toys below!</p>

<?php
require_once __DIR__ . '/views/toys/index.php';
require_once __DIR__ . '/views/partials/footer.php';
?>