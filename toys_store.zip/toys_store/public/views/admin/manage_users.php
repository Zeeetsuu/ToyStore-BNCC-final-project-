<?php
require_once __DIR__ . '/../../partials/header.php';
require_once __DIR__ . '/../../auth/db.php';
require_once __DIR__ . '/../../middleware.php';

redirectIfNotAuthenticated();
redirectIfNotAdmin();

$query = $conn->prepare("SELECT * FROM users");
$query->execute();
$results = $query->get_result();
?>

<h1>Manage Users</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Admin</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($user = $results->fetch_assoc()): ?>
        <tr>
            <td><?php echo $user['id']; ?></td>
            <td><?php echo $user['username']; ?></td>
            <td><?php echo $user['email']; ?></td>
            <td><?php echo $user['is_admin'] ? 'Yes' : 'No'; ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
require_once __DIR__ . '/../../partials/footer.php';
?>