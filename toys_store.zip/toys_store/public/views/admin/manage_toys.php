<?php
require_once __DIR__ . '/../../partials/header.php';
require_once __DIR__ . '/../../auth/db.php';
require_once __DIR__ . '/../../middleware.php';

redirectIfNotAuthenticated();
redirectIfNotAdmin();

$query = $conn->prepare("SELECT * FROM toys");
$query->execute();
$results = $query->get_result();
?>

<h1>Manage Toys</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($toy = $results->fetch_assoc()): ?>
        <tr>
            <td><?php echo $toy['id']; ?></td>
            <td><?php echo $toy['name']; ?></td>
            <td><?php echo $toy['description']; ?></td>
            <td><?php echo $toy['price']; ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
require_once __DIR__ . '/../../partials/footer.php';
?>