<?php
require_once __DIR__ . '/../partials/header.php';
?>

<h2>Admin Dashboard</h2>
<!-- Admin functionalities -->

<?php
require_once __DIR__ . '/../partials/footer.php';
?>