<?php
require_once __DIR__ . '/../../partials/header.php';
require_once __DIR__ . '/../../middleware.php';

redirectIfNotAuthenticated();
redirectIfNotAdmin();
?>

<h1>Admin Dashboard</h1>
<p>Welcome, Admin! Here you can manage the toy store.</p>

<ul>
    <li><a href="/toys_store/public/views/admin/manage_users.php">Manage Users</a></li>
    <li><a href="/toys_store/public/views/admin/manage_toys.php">Manage Toys</a></li>
</ul>

<?php
require_once __DIR__ . '/../../partials/footer.php';
?>