<?php
require_once 'db.php'; // Include your database connection

$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

$query = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$query->bind_param("sss", $name, $email, $password);

if ($query->execute()) {
    header("Location: login.php");
} else {
    echo "Error: " . $query->error;
}
?>