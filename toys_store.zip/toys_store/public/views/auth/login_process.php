<?php
session_start();
require_once 'db.php'; // Include your database connection

$email = $_POST['email'];
$password = $_POST['password'];

$query = $conn->prepare("SELECT * FROM users WHERE email = ?");
$query->bind_param("s", $email);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    header("Location: /toys_store/public/index.php");
} else {
    echo "Invalid email or password";
}
?>