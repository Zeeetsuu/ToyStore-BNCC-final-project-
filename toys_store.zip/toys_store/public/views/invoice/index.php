<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../middleware.php';

function formatRupiah($number) {
    return 'Rp' . number_format($number, 2, ',', '.');
}

redirectIfNotAuthenticated();

$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT * FROM invoices WHERE user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
?>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 1em;
        font-family: 'Arial', sans-serif;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }
    table th,
    table td {
        padding: 12px 15px;
    }
    table tbody tr {
        border-bottom: 1px solid #dddddd;
    }
    table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }
    table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }
    table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }
</style>

<h2>Invoices</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Total</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php while($invoice = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $invoice['id']; ?></td>
            <td><?php echo formatRupiah ($invoice['total']); ?></td>
            <td><?php echo $invoice['created_at']; ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
require_once __DIR__ . '/../partials/footer.php';
?>