<?php
session_start();

function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirectIfNotAuthenticated() {
    if (!isAuthenticated()) {
        header("Location: /toys_store/public/views/auth/login.php");
        exit();
    }
}

function redirectIfNotAdmin() {
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        header("Location: /toys_store/public/views/home.php");
        exit();
    }
}

?>