<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';

function formatRupiah($number) {
    return 'Rp' . number_format($number, 2, ',', '.');
}

// Handle search and filter
$search = isset($_GET['search']) ? $_GET['search'] : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';

$query = "SELECT * FROM toys WHERE name LIKE ? OR description LIKE ?";
if ($filter) {
    $query .= " AND category = ?";
}

$stmt = $conn->prepare($query);
if ($filter) {
    $searchParam = '%' . $search . '%';
    $stmt->bind_param("sss", $searchParam, $searchParam, $filter);
} else {
    $searchParam = '%' . $search . '%';
    $stmt->bind_param("ss", $searchParam, $searchParam);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<style>
    .search-filter {
        margin: 20px 0;
    }

    .search-filter input[type="text"] {
        padding: 10px;
        width: 300px;
        margin-right: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .search-filter select {
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .search-filter button {
        padding: 10px 20px;
        border-radius: 5px;
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }

    .toy-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .toy-item {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin: 20px;
        padding: 20px;
        text-align: center;
        width: 200px;
    }

    .toy-item img {
        max-width: 100%;
        border-radius: 10px;
    }

    .toy-item h3 {
        font-size: 1.2em;
        color: #333;
    }

    .toy-item p {
        color: #666;
    }

    .toy-item .price {
        color: #4CAF50;
        font-weight: bold;
    }

    .toy-item a {
        text-decoration: none;
        color: #009879;
        font-weight: bold;
        display: inline-block;
        margin-top: 10px;
    }
</style>

<h2>Dashboard</h2>

<div class="search-filter">
    <form action="dashboard.php" method="GET">
        <input type="text" name="search" placeholder="Search toys..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="filter">
            <option value="">All Categories</option>
            <option value="action" <?php if ($filter == 'action') echo 'selected'; ?>>Action</option>
            <option value="educational" <?php if ($filter == 'educational') echo 'selected'; ?>>Educational</option>
            <option value="puzzle" <?php if ($filter == 'puzzle') echo 'selected'; ?>>Puzzle</option>
            <!-- Add more categories as needed -->
        </select>
        <button type="submit">Search</button>
    </form>
</div>

<div class="toy-list">
    <?php while ($toy = $result->fetch_assoc()): ?>
        <div class="toy-item">
            <img src="<?php echo $toy['image_url']; ?>" alt="<?php echo htmlspecialchars($toy['name']); ?>">
            <h3><?php echo htmlspecialchars($toy['name']); ?></h3>
            <p><?php echo htmlspecialchars($toy['description']); ?></p>
            <p class="price"><?php echo formatRupiah($toy['price']); ?></p>
            <a href="detail.php?id=<?php echo $toy['id']; ?>">View Details</a>
        </div>
    <?php endwhile; ?>
</div>

<?php
require_once __DIR__ . '/../partials/footer.php';
?>