<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';

$id = $_GET['id'];

// Start transaction
$conn->begin_transaction();

try {
    // Delete related rows in invoice_items
    $query = $conn->prepare("DELETE FROM invoice_items WHERE toy_id = ?");
    $query->bind_param("i", $id);
    $query->execute();

    // Delete the toy
    $query = $conn->prepare("DELETE FROM toys WHERE id = ?");
    $query->bind_param("i", $id);
    $query->execute();

    // Commit transaction
    $conn->commit();
    
    header("Location: index.php");
} catch (mysqli_sql_exception $exception) {
    // Rollback transaction on error
    $conn->rollback();
    echo "Error: " . $exception->getMessage();
}
?>