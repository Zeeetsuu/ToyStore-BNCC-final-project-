<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';

function formatRupiah($number) {
    return 'Rp' . number_format($number, 2, ',', '.');
}

$id = $_GET['id'];
$query = $conn->prepare("SELECT * FROM toys WHERE id = ?");
$query->bind_param("i", $id);
$query->execute();
$result = $query->get_result();
$toy = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Toy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #4CAF50;
        }

        form {
            background: #fff;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            form {
                padding: 10px;
            }

            input[type="text"],
            input[type="number"],
            textarea {
                padding: 8px;
            }

            button {
                padding: 10px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<h2>Edit Toy</h2>
<form action="edit_process.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $toy['id']; ?>">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="<?php echo $toy['name']; ?>" required>
    <br>
    <label for="description">Description:</label>
    <textarea id="description" name="description" required><?php echo $toy['description']; ?></textarea>
    <br>
    <label for="price">Price:</label>
    <input type="number" id="price" name="price" value="<?php echo $toy['price']; ?>" required>
    <br>
    <button type="submit">Edit</button>
</form>

<?php
require_once __DIR__ . '/../partials/footer.php';
?>

</body>
</html>