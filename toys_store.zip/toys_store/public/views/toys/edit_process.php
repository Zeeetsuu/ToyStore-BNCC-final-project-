<?php
require_once __DIR__ . '/../auth/db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$description = $_POST['description'];
$price = $_POST['price'];

$query = $conn->prepare("UPDATE toys SET name = ?, description = ?, price = ? WHERE id = ?");
$query->bind_param("ssdi", $name, $description, $price, $id);

if ($query->execute()) {
    header("Location: index.php");
} else {
    echo "Error: " . $query->error;
}
?>