<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../middleware.php';

function formatRupiah($number) {
    return 'Rp' . number_format($number, 2, ',', '.');
}

$id = $_GET['id'];
$query = $conn->prepare("SELECT * FROM toys WHERE id = ?");
$query->bind_param("i", $id);
$query->execute();
$result = $query->get_result();
$toy = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Toy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #4CAF50;
        }

        .toy-details {
            background: #fff;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .toy-details p {
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .toy-details, form {
                padding: 10px;
            }

            input[type="number"] {
                padding: 8px;
            }

            button {
                padding: 10px;
                font-size: 14px;
            }
        }
    </style>
    <script>
        function updatePrice() {
            const price = <?php echo $toy['price']; ?>;
            const quantity = document.getElementById('quantity').value;
            const totalPrice = price * quantity;
            document.getElementById('total-price').innerText = 'Price: ' + formatRupiah(totalPrice);
        }

        function formatRupiah(number) {
            return 'Rp' + number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,').replace('.', ',');
        }
    </script>
</head>
<body>

<div class="toy-details">
    <h2><?php echo $toy['name']; ?></h2>
    <p><?php echo $toy['description']; ?></p>
    <p id="total-price">Price: <?php echo formatRupiah($toy['price']); ?></p>
</div>

<form action="add_to_cart.php" method="POST">
    <input type="hidden" name="toy_id" value="<?php echo $toy['id']; ?>">
    <label for="quantity">Quantity:</label>
    <input type="number" id="quantity" name="quantity" value="1" min="1" required oninput="updatePrice()">
    <button type="submit">Add to Cart</button>

</form>

<?php
require_once __DIR__ . '/../partials/footer.php';
?>

</body>
</html>