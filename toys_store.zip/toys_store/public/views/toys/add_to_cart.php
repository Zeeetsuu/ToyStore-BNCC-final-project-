<?php
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../middleware.php';

redirectIfNotAuthenticated();

$toy_id = $_POST['toy_id'];
$quantity = $_POST['quantity'];
$user_id = $_SESSION['user_id'];

// Check if the toy is already in the cart
$query = $conn->prepare("SELECT * FROM carts WHERE user_id = ? AND toy_id = ?");
$query->bind_param("ii", $user_id, $toy_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    // If the toy is already in the cart, update the quantity
    $cart_item = $result->fetch_assoc();
    $new_quantity = $cart_item['quantity'] + $quantity;
    $query = $conn->prepare("UPDATE carts SET quantity = ? WHERE user_id = ? AND toy_id = ?");
    $query->bind_param("iii", $new_quantity, $user_id, $toy_id);
} else {
    // If the toy is not in the cart, insert a new record
    $query = $conn->prepare("INSERT INTO carts (user_id, toy_id, quantity) VALUES (?, ?, ?)");
    $query->bind_param("iii", $user_id, $toy_id, $quantity);
}

if ($query->execute()) {
    header("Location: /toys_store/public/views/cart/index.php");
} else {
    echo "Error: " . $query->error;
}
?>