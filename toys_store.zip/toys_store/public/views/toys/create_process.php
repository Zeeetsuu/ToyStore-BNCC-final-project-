<?php
require_once __DIR__ . '/../auth/db.php';

$name = $_POST['name'];
$description = $_POST['description'];
$price = $_POST['price'];

$query = $conn->prepare("INSERT INTO toys (name, description, price) VALUES (?, ?, ?)");
$query->bind_param("ssd", $name, $description, $price);

if ($query->execute()) {
    header("Location: index.php");
} else {
    echo "Error: " . $query->error;
}
?>