</main>
    <footer>
        <p>&copy; 2024 Toys Store</p>
    </footer>
</body>
</html>