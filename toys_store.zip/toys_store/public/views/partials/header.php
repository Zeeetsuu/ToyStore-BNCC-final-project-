<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/toys_store/public/css/style.css">
    <title>Toys Store</title>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/toys_store/public/index.php">Home</a></li>
                <li><a href="/toys_store/public/views/auth/login.php">Login</a></li>
                <li><a href="/toys_store/public/views/auth/register.php">Register</a></li>
                <li><a href="/toys_store/public/views/toys/index.php">Toys</a></li>
                <li><a href="/toys_store/public/views/cart/index.php">Cart</a></li>
                <li><a href="/toys_store/public/views/invoice/index.php">Invoice</a></li>
                <li><a href="/toys_store/public/views/admin/index.php">Admin</a></li>
            </ul>
        </nav>
    </header>
    <main>