<!DOCTYPE html>
<html>
<head>
    <title>Website Title</title>
    <style>
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #f4f4f4;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header .logo {
            font-size: 24px;
            font-weight: bold;
        }
        .header .nav {
            display: flex;
            gap: 15px;
        }
        .header .nav a {
            text-decoration: none;
            color: #009879;
            font-size: 16px;
        }
        .header .nav a:hover {
            color: #007961;
        }
        .header .logout-btn {
            background-color: #009879;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        .header .logout-btn:hover {
            background-color: #007961;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">Website Title</div>
        <div class="nav">
            <a href="toys.php">Toys</a>
            <a href="admin.php">Admin</a>
            <form action="logout.php" method="POST" style="display:inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>