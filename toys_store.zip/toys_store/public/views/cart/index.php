<?php
require_once __DIR__ . '/../partials/header.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../middleware.php';

function formatRupiah($number) {
    return 'Rp' . number_format($number, 2, ',', '.');
}

redirectIfNotAuthenticated();

$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT c.id, t.name, t.price, c.quantity FROM carts c JOIN toys t ON c.toy_id = t.id WHERE c.user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
?>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 1em;
        font-family: 'Arial', sans-serif;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }
    table th,
    table td {
        padding: 12px 15px;
    }
    table tbody tr {
        border-bottom: 1px solid #dddddd;
    }
    table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }
    table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }
    table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }
    .action-links a {
        margin-right: 10px;
        text-decoration: none;
        color: #009879;
    }
</style>

<h2>Cart</h2>
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php while($item = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $item['name']; ?></td>
            <td><?php echo formatRupiah ($item['price']); ?></td>
            <td><?php echo $item['quantity']; ?></td>
            <td><?php echo formatRupiah ($item['price'] * $item['quantity']); ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<a href="checkout.php">Checkout</a>

<?php
require_once __DIR__ . '/../partials/footer.php';
?>