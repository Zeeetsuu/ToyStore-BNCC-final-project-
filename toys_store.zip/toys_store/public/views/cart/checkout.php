<?php
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../middleware.php';

redirectIfNotAuthenticated();

$user_id = $_SESSION['user_id'];

// Get cart items
$query = $conn->prepare("SELECT t.id, t.price, c.quantity FROM carts c JOIN toys t ON c.toy_id = t.id WHERE c.user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();

$total = 0;
$items = [];
while ($item = $result->fetch_assoc()) {
    $total += $item['price'] * $item['quantity'];
    $items[] = $item;
}

// Create invoice
$query = $conn->prepare("INSERT INTO invoices (user_id, total) VALUES (?, ?)");
$query->bind_param("id", $user_id, $total);
$query->execute();
$invoice_id = $query->insert_id;

// Create invoice items
foreach ($items as $item) {
    $query = $conn->prepare("INSERT INTO invoice_items (invoice_id, toy_id, quantity, price) VALUES (?, ?, ?, ?)");
    $query->bind_param("iiid", $invoice_id, $item['id'], $item['quantity'], $item['price']);
    $query->execute();
}

// Clear cart
$query = $conn->prepare("DELETE FROM carts WHERE user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();

header("Location: /toys_store/public/views/invoice/index.php");
?>