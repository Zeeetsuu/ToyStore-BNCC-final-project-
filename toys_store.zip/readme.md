Nama Anggota Kelompok:
1. Akmal Hendrian Malik - 2702352383
2. Nugraha Byru Sapphire - 2702280043
3. Vincentius Aaron - 2702261611

*Catatan Penting:
- Repository website yaitu http://localhost/toys_store/public/index.php
- Repository Database SQL yaitu toys_store/database/final_project.sql

Terima Kasih...